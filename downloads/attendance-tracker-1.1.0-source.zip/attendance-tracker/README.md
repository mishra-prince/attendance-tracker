# Threshold — Attendance Tracker

A college attendance app for Android and the web. Students check in using their phones; teachers review and submit session attendance. No RFID cards or tags are required.

## Updated in 1.1

- Native Android Bluetooth scanning and teacher-phone broadcasting, with rotating classroom signals.
- A new student dashboard, Bluetooth progress screen, teacher controls and camera retry flow.
- Server-side enrollment, section, teacher ownership and scheduled-time checks.
- Dwell tracking with duplicate suppression and no credit for long detection gaps.
- Teacher review for missing evidence; existing manual and medical attendance is preserved.
- In-memory access tokens, rotating HttpOnly refresh cookies, replay detection and immediate session revocation.
- Restored database migrations, repaired admin organization setup, safer APK defaults and guarded development seeding.

**The APK requires the updated backend.** Both phones need the app open on their Bluetooth screen and an internet connection. Background attendance and verified hardware/device attestation are future work. Bluetooth measures phone proximity; it does not prove a person's identity or prevent every real-time relay.

See [Bluetooth setup, hardware options and security limits](docs/BLUETOOTH_SECURITY.md) for deployment, a two-phone pilot, policy settings and a higher-assurance roadmap.

## Stack

React 18, TypeScript, Vite, Tailwind, React Router 7, Capacitor 8, native Android BLE; Express, Prisma 5 and PostgreSQL.

## Local setup

Requirements: Node.js 22+, PostgreSQL 14+. Android builds additionally require JDK 21 and Android SDK 36.

1. Create a local PostgreSQL database.
2. Copy server/.env.example to server/.env. Set DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET and BLE_BEACON_SECRET. Generate three different random secrets of at least 32 characters:

       node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"

3. Install and migrate:

       cd server
       npm ci
       npx prisma generate
       npm run migrate:deploy
       npm run dev

4. In another terminal:

       cd client
       npm ci
       npm run dev

The client runs at http://localhost:5173 and proxies /api to http://localhost:4100. Set CLIENT_URL if using a different browser origin.

For sample data, use a disposable local database, explicitly set ALLOW_DEMO_SEED=true and a DEMO_SEED_PASSWORD of at least 12 characters, then run npm run seed from server/. This seed wipes its target database and is blocked in production. Demo accounts include student@att.edu, teacher@att.edu, hod@att.edu, admin@att.edu and superadmin@att.edu, using your chosen demo password. Never seed a live institution database.

## Android

Copy client/.env.example to client/.env.production and set VITE_API_BASE_URL to your institution-owned HTTPS address.

    cd client
    npm ci
    npm run android:sync
    cd android
    ./gradlew assembleDebug

Output: client/android/app/build/outputs/apk/debug/app-debug.apk. Debug APKs are for testing. Production releases need your protected release signing key. Both student scanning and teacher broadcasting are available only in the Android app; browsers provide the existing QR/manual alternatives.

## Verification

    cd server
    npm test
    npm run build
    cd ../client
    npm run build
    cd android
    ./gradlew lintDebug testDebugUnitTest assembleDebug

Integration tests create an isolated PGlite PostgreSQL database, apply the committed migrations and test the Express API over HTTP. They require no production database or account credentials.

## Production configuration

Every required setting is documented in server/.env.example and client/.env.example. Use production HTTPS, exact CORS origins and a trusted proxy configuration. Read the [deployment and migration notes](docs/BLUETOOTH_SECURITY.md#server-deployment) before updating an existing database, especially one previously managed with prisma db push.

The existing role-based attendance, session, leave, correction, notification, timetable and supervised-enrollment modules remain in the repository. Documentation for intended architecture is in docs/. This update hardens the Bluetooth and authentication paths; it is not a complete audit or certification of every inherited module.
